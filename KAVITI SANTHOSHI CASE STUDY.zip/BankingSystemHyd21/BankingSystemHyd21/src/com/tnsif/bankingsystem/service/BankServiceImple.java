package com.tnsif.bankingsystem.service;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.tnsif.bankingsystem.entity.Account;
import com.tnsif.bankingsystem.entity.Beneficiary;
import com.tnsif.bankingsystem.entity.Customer;
import com.tnsif.bankingsystem.entity.Transaction;

public class BankServiceImple implements BankingInterface {

	private Map<Integer,Customer> customers=new HashMap<Integer, Customer>();
	private Map<Integer,Account> accounts=new HashMap<Integer, Account>();
    private Map<Integer,Transaction> transactions=new HashMap<Integer, Transaction>();
	private Map<Integer,Beneficiary> beneficiaries=new HashMap<Integer, Beneficiary>();
	
	
	@Override
	public void addCustomer(Customer customer) {
		
		customers.put(customer.getCustomerID(),customer);
		}

	
	public void addAccount(Account account) {
		
		accounts.put(account.getAccountID(),account);
		//add Account to accounts map,key-customerID
	}
	
	
		public void addTransaction(Transaction transaction) {
			transactions.put(transaction.getTransactionID(),transaction);
			//add transaction to transactions map,key-transactionID
			//and based on transaction type(deposit or withdraw)update the account balance
	}
	
		
		public void addBeneficiary(Beneficiary beneficiary) {
		beneficiaries.put(beneficiary.getBeneficiaryID(),beneficiary);
	    //add beneficiary to beneficiaries map,key-beneficiaryID
		}
	
	

		@Override
		public Customer findCustomerByID(int ID) {
			
			return customers.get(ID);
		}


		@Override
		public Collection<Customer> getAllCustomers() {
		
			return customers.values();
		}


		@Override
		public Account findAccountByID(int ID) {
			
			return accounts.get(ID);
		}


		@Override
		public Collection<Account> getAllAccounts() {
			
			return accounts.values();
		}


		@Override
		public Transaction findTransactionByID(int ID) {
			
			return transactions.get(ID);
		}


		@Override
		public Collection<Transaction> getAllTransactions() {
	
			return transactions.values();
		}


		@Override
		public Beneficiary findBeneficiaryByID(int ID) {
			
			return beneficiaries.get(ID);
		}


		@Override
		public Collection<Beneficiary> getAllBeneficiaries() {
		
			return beneficiaries.values();
		}
		
		
		}
		
		
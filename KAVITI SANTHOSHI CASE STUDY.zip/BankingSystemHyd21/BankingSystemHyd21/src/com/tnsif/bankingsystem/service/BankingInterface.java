package com.tnsif.bankingsystem.service;

import java.util.Collection;

import com.tnsif.bankingsystem.entity.Account;
import com.tnsif.bankingsystem.entity.Beneficiary;
import com.tnsif.bankingsystem.entity.Customer;
import com.tnsif.bankingsystem.entity.Transaction;

public interface BankingInterface {

	
	public void addCustomer(Customer customer);
	
	//get only customer based on id
	Customer findCustomerByID(int ID);
	//get all customers details
	Collection<Customer> getAllCustomers();
	
	
	public void addAccount(Account account);
	//get only account based on id
	Account findAccountByID(int ID);
	//get all account details
	Collection<Account> getAllAccounts();
	
	
	public void addTransaction(Transaction transaction);
	//get only transaction based on id
	Transaction findTransactionByID(int ID);
	//get all transaction details
	Collection<Transaction> getAllTransactions();
	
	
	public void addBeneficiary(Beneficiary beneficiary);
	//get only beneficiary based on id
	Beneficiary findBeneficiaryByID(int ID);
	//get all beneficiary details
	Collection<Beneficiary> getAllBeneficiaries();
	
}

package com.example.Springcrudshadanproject.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Springcrudshadanproject.entity.Placement;
import com.example.Springcrudshadanproject.repository.PlacementRepo;

@Service
public class PlacementService {
	
	@Autowired
	private PlacementRepo irepo;
	
	//adding placement details
	public Placement addPlacement(Placement placement) {
		return irepo.save(placement);
	}
	
	//update
	public Placement updatePlacement(Placement placement) {
		Long id=placement.getPlacementid();
		Placement placement1=irepo.findById(id).get();
		placement1.setName(placement.getName());
		placement1.setQualification(placement.getQualification());
		return irepo.save(placement1);
	}
   //search
	public Placement searchPlacement(Placement placement) {
		placement.getPlacementid();
		return placement;
	}
	//delete
	public void deletePlacement(Long id) {
		irepo.deleteById(id);
	}

	
	public void cancelPlacement(Long id) {
		// TODO Auto-generated method stub
		
	}
}
package com.example.Springcrudshadanproject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Springcrudshadanproject.entity.Placement;
import com.example.Springcrudshadanproject.service.PlacementService;

@RestController
public class PlacementController {
    
    @Autowired
    private PlacementService pService;

    @PostMapping("/addPlacement")
    public Placement addPlacement(@RequestBody Placement placement) {
        return pService.addPlacement(placement);
    }

    @PutMapping("/updatePlacement")
    public Placement updatePlacement(@RequestBody Placement placement) {
    	 return pService.updatePlacement(placement);
    }

    @PostMapping("/searchPlacement")
    public Placement searchPlacement(@RequestBody Placement placement) {
    	return pService.searchPlacement(placement);
    }

    @DeleteMapping("/cancelPlacement/{id}")
    public void cancelPlacement(@PathVariable Long id) {
    	   pService.cancelPlacement(id);
    }
}
package com.example.Springcrudshadanproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringcrudshadanprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringcrudshadanprojectApplication.class, args);
	}

}

package com.example.Springcrudshadanproject.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Springcrudshadanproject.entity.Placement;

public interface PlacementRepo extends JpaRepository<Placement,Long> {

}

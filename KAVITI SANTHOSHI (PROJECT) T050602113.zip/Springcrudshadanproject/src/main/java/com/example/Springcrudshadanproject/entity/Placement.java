package com.example.Springcrudshadanproject.entity;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table

public class Placement {
	@Id
	private Long id;
	private String name;
	private String college;
	private LocalDate date;
	private String qualification;
	private int year;
	public long getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCollege() {
		return college;
	}
	public void setCollege(String college) {
		this.college = college;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getPlacementid() {
		return null;
		
	}
	public Object getDept() {
		return null;
	}
}
	
	
	

package com.example.Springcrudshadanproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringcrudshadanprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
